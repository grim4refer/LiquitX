package com.ruse.model;

public enum GraphicHeight {

	LOW,
	
	MIDDLE,
	
	HIGH;
}
