package com.ruse.world.content.skill.impl.farming;

public class Calquat {
}
