/**
 * 
 */
package com.ruse.world.content.dialogue.quests;

/**
 * @author Stan
 *
 */
public class QuestManager {

	
}
