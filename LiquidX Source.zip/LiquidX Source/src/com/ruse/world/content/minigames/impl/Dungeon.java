package com.ruse.world.content.minigames.impl;

public class Dungeon {

}
